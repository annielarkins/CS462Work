const { app, Tray, Menu: { buildFromTemplate } } = require('electron'),
      path = require('path'),
      iconMapItem = {
        linux: 'postmanlogo-head-orange',
        win32: 'postmanlogo-head-orange',
        darwin: 'postmanlogo-head-blackTemplate'
      };

let tray;

module.exports = {

  setTrayIcon () {
    const iconName = this.getIcon();
        tray = new Tray(path.join(__dirname, '..', 'assets', 'images', `${iconName}.png`));

    // taking name from config file it will have space in app name
    tray.setToolTip(pm.config.get('AppName'));
  },

  getIcon () {
    const iconName = iconMapItem[process.platform];
    return iconName;
  },

  refreshContextMenu (prependItems) {
    tray.setContextMenu(buildFromTemplate(prependItems));
  }
};
